import{c as o}from"./createLucideIcon-Dgf_Eqpt.js";const t=[["path",{d:"m8 3 4 8 5-5 5 15H2L8 3z",key:"otkl63"}]],c=o("mountain",t);export{c as M};
